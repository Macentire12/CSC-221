#Malachi Lewis
#3/17/24
#CSC-221 
import csv
from person import Person

class Employee(Person):
    def __init__(self, firstName, lastName, position, salary, status):
        super().__init__(firstName, lastName)
        self.__position = position
        self.__status = status
        self.__salary = salary

    def __repr__(self):
      return f"{self.firstName}, {self.lastName}, {self.__position},{self.__salary}, {self.__status}, {self.get_email()})"


    def get_status(self):
        return self.__status

    def set_status(self, status):
        self.__status = status

    def get_position(self):
        return self.__position

    def set_position(self, position):
        self.__position = position

    def get_salary(self):
        return self.__salary

    def set_salary(self, salary):
        self.__salary = salary

def main():
    choice = ""
    while choice != "3":
        print("Menu")
        print("----------------")
        print("1. Enter Employee Info and write to .txt and .csv files: " 
              + "\n2. Read Employee Info from .txt and csv files (if existing) " 
              + "\n3. Exit Program\n")
        choice = input("Please enter your choice: ")

        if choice == "1":
            emp_list = []
            empNum = int(input("How many employees would you like to enter: "))

            for i in range(empNum):
                first = input("First Name: ")
                last = input("Last Name: ")
                position = input("Position: ")
                status = input("Part/Full Time: ")
                salary = input("Salary: ")
                emp_list.append(Employee(first, last, position, salary, status))

            header = f"{'Last':<2} {'First':<2} {'Position':<2} {'Salary':<2} {'Part/Full Time':<2} {'Email':<2}"

            with open("employees.txt", "w") as outFile:
                outFile.write(header + "\n")
                outFile.write("--------" * 10 + "\n")
                for emp in emp_list:
                    outFile.write(repr(emp) + "\n")

            with open("employees.csv", "w", newline="") as csvFile:
                writer = csv.writer(csvFile)
                writer.writerow(["Last", "First", "Position", "Salary", "Part/Full Time"," Email" ])
                for emp in emp_list:
                    writer.writerow([emp.firstName , emp.lastName , emp.get_position() , emp.get_salary(), emp.get_status(), emp.get_email()])

        elif choice == "2":
            try:
                with open("employees.txt", "r") as inFile:
                    print("Contents of employees.txt:")
                    print(inFile.read())

                with open("employees.csv", "r") as csvFile:
                    print("\nContents of employees.csv:")
                    reader = csv.reader(csvFile)
                    for row in reader:
                        print(row)

            except FileNotFoundError:
                print("File Error! Please use option 1!")

        elif choice == "3":
            print("Closing program! Goodbye.")

        else:
            print("This is not a valid option! Please choose from the menu.\n")

if __name__ == "__main__":
    main()
