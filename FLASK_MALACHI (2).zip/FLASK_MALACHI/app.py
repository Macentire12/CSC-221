from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)


menu = {
    "apple": {"price": 1.00, "image": "apple.png"},
    "banana": {"price": 0.50, "image": "banana.png"},
    "orange": {"price": 1.20, "image": "orange.png"},
    "grapes": {"price": 2.00, "image": "grapes.png"}
}


shopping_cart = {}

@app.route("/")
def index():
    return render_template("index.html", menu=menu)

@app.route("/add_to_cart", methods=["POST"])
def add_to_cart():
    item = request.form["item"]
    quantity = int(request.form["quantity"])
    if item in menu:
        if item in shopping_cart:
            shopping_cart[item]["quantity"] += quantity
        else:
            shopping_cart[item] = {"price": menu[item]["price"], "quantity": quantity}
    return redirect(url_for("index"))

@app.route("/remove_from_cart", methods=["POST"])
def remove_from_cart():
    item = request.form["item"]
    if item in shopping_cart:
        del shopping_cart[item]
    return redirect(url_for("view_cart"))

@app.route("/view_cart")
def view_cart():
    total = sum(item["price"] * item["quantity"] for item in shopping_cart.values())
    total_formatted = "${:.2f}".format(total)  
    return render_template("cart.html", cart=shopping_cart, total=total_formatted, menu=menu)

@app.route("/checkout", methods=["GET", "POST"])
def checkout():
    if request.method == "POST":
        name = request.form["name"]
        address = request.form["address"]
        email = request.form["email"]
        
        
        receipt = f"Receipt for {name}\n"
        receipt += f"Address: {address}\n"
        receipt += f"Email: {email}\n\n"
        receipt += "Items:\n"
        for item, details in shopping_cart.items():
            receipt += f"{item}: ${details['price']} x {details['quantity']} = ${details['price'] * details['quantity']:.2f}\n"  # Format item prices
        receipt += f"\nTotal Amount: ${sum(details['price'] * details['quantity'] for details in shopping_cart.values()):.2f}\n"  # Format total amount
        
        
        with open("receipt.txt", "w") as file:
            file.write(receipt)
        
        
        shopping_cart.clear()
        
        
        return render_template("receipt.html", receipt=receipt)
    else:
        total = sum(item["price"] * item["quantity"] for item in shopping_cart.values())
        return render_template("checkout.html", total=total)

if __name__ == "__main__":
    app.run(debug=True)
