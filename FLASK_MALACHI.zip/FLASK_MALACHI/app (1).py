from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)

menu = [
    {'id': 1, 'name': 'Margherita', 'price': 9.99},
    {'id': 2, 'name': 'Pepperoni', 'price': 10.99},
    {'id': 3, 'name': 'Vegetarian', 'price': 11.99}
]

cart = []

@app.route('/')
def index():
    return render_template('index.html', menu=menu)

@app.route('/add_to_cart/<int:item_id>')
def add_to_cart(item_id):
    item = next((item for item in menu if item['id'] == item_id), None)
    if item:
        cart.append(item)
    return redirect(url_for('checkout'))  # Redirect to the checkout page

@app.route('/view_cart')
def view_cart():
    return render_template('cart.html', cart=cart)

@app.route('/checkout')
def checkout():
    return render_template('checkout.html', cart=cart)

if __name__ == '__main__':
    app.run(debug=True)
