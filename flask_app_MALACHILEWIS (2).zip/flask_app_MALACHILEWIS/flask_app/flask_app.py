from flask import Flask, render_template , request 

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/submit', methods=('POST','GET'))
def submit():
    
    
    return render_template('submit.html')

@app.route('/form_info',methods=['POST'])
def form_info():
    info1 =request.form['first_name']
    info2 =request.form['last_name']
    info3 =request.form['email']
    return render_template('.html', info1=info1,info2=info2,info3=info3)

if __name__ == '__main__':
    app.run(debug=True)
